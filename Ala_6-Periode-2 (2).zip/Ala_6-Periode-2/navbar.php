<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Navbar.css">
</head>
<body>
    

<header>
<section class="top-nav">
            <div>
                <img id="navbar-logo" src="uploads/Logo_Ala.png" width="50px">
            </div>
            <input id="menu-toggle" type="checkbox" />
            <label class='menu-button-container' for="menu-toggle">
                <div class='menu-button'></div>
            </label>
            <ul class="menu">
                <a href="Home.php">Home</a>
                <a href="Recepten.php">Recepten</a>
                <a href="Bestel.php">Bestellen</a>
                <a href="Contact.php">Contact</a>
                <a href="inloggen.php">Inloggen</a>
            </ul>
        </section>
    </header>
</body>
</html>