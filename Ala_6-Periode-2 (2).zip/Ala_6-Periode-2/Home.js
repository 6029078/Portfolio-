function getRandomRecipe() {
    // Reload the page to get a new random recipe
    location.reload();
}


let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}


function applyDiscount(boekId) {
    // Voeg hier de AJAX-implementatie toe om korting toe te passen op de server
    fetch('apply_discount.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ boekId: boekId }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update de weergave van de prijs en andere gerelateerde elementen voor het specifieke boek
            const oldPriceElement = document.querySelector('.old-price[data-boek-id="' + boekId + '"]');
            const discountElement = document.querySelector('.discount[data-boek-id="' + boekId + '"]');
            const btnElement = document.querySelector('.btn[data-boek-id="' + boekId + '"]');
 
            oldPriceElement.style.display = 'none';
            discountElement.style.display = 'none';
            btnElement.removeAttribute('onclick');
            btnElement.innerText = 'Bestellen';
        } else {
            console.error('Er is iets fout gegaan bij het toepassen van korting.');
        }
    })
    .catch(error => {
        console.error('Er is iets fout gegaan bij het verwerken van de aanvraag:', error);
    });
}
 
function removeDiscount(boekId) {
    // Voeg hier de AJAX-implementatie toe om korting te verwijderen op de server
    fetch('remove_discount.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ boekId: boekId }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update de weergave van de prijs en andere gerelateerde elementen voor het specifieke boek
            const oldPriceElement = document.querySelector('.old-price[data-boek-id="' + boekId + '"]');
            const discountElement = document.querySelector('.discount[data-boek-id="' + boekId + '"]');
            const btnElement = document.querySelector('.btn[data-boek-id="' + boekId + '"]');
 
            oldPriceElement.style.display = 'block';
            discountElement.style.display = 'block';
            btnElement.removeAttribute('onclick');
            btnElement.innerText = 'Bestellen';
        } else {
            console.error('Er is iets fout gegaan bij het verwijderen van korting.');
        }
    })
    .catch(error => {
        console.error('Er is iets fout gegaan bij het verwerken van de aanvraag:', error);
    });
}


function confirmDelete(recipeId) {
    var confirmDelete = confirm("Are you sure you want to delete this recipe?");
    if (confirmDelete) {
        window.location.href = "delete_recipe.php?recipe_id=" + recipeId;
    }
}