<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('navbar.php'); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Home.css">
    <title>Home</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="Home.js" defer></script>
</head>
<body>

<div class="container">
    <!-- Your existing code... -->

    <?php foreach ($boeken as $boek) { ?>
        <div class="recipe-container" data-book-id="<?php echo $boek['Boek_id']; ?>">
            <div class="recipe-content">
                <span class="book-name"><?php echo $boek['Boek_naam']; ?></span><br>
                <?php if (!empty($boek['Boek_img'])) : ?>
                    <img src="uploads/<?php echo $boek['Boek_img']; ?>" alt="<?php echo $boek['Boek_naam']; ?>" width="150"><br>
                <?php else : ?>
                    Geen afbeelding beschikbaar<br>
                <?php endif; ?>
                
                <div>
                    <button class="btn more-info">Recept tonen</button>
                    <button class="btn delete-recipe" data-recipe-id="<?php echo $boek['Boek_id']; ?>">Verwijder recept</button>
                </div>
            </div>
            <div class="overlay-bg"></div>
        </div>
    <?php } ?>

    <!-- Your existing code... -->
</div>

<!-- Your existing code... -->

<script>
    $(document).ready(function () {
        $(".delete-recipe").on("click", function () {
            var recipeId = $(this).data("recipe-id");
            confirmDelete(recipeId);
        });

        function confirmDelete(recipeId) {
            var confirmDelete = confirm("Are you sure you want to delete this recipe?");
            if (confirmDelete) {
                window.location.href = "delete_recipe.php?recipe_id=" + recipeId;
            }
        }
    });
</script>

<!-- Your existing code... -->

</body>
</html>
