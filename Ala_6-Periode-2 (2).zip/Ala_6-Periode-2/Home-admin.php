<?php include('delete_recipe-home.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('navbar-admin.php'); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Recepten.css">
    <title>Home</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="Home.js" defer></script>
    <style>
        html, body {
            margin: 0;
            background: linear-gradient(rgb(0, 0, 0), rgb(140, 140, 140));
            color: white;
        }

        /* ... Other styles ... */

    </style>
</head>
<body>

    <?php
    require_once 'dbconnect.php';
    try {
        $sql = "SELECT * FROM recepteboeken";
        $result = $conn->query($sql);
        $boeken = $result->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        echo "Er is iets fout gegaan met ophalen.";
    }
    ?>

    <?php foreach ($boeken as $boek) { ?>
        <div class="recipe-container" data-book-id="<?php echo $boek['Boek_id']; ?>">
            <div class="recipe-content">
                <span class="book-name"><?php echo $boek['Boek_naam']; ?></span><br>
                <?php if (!empty($boek['Boek_img'])) : ?>
                    <img src="uploads/<?php echo $boek['Boek_img']; ?>" alt="<?php echo $boek['Boek_naam']; ?>" width="150"><br>
                <?php else : ?>
                    Geen afbeelding beschikbaar<br>
                <?php endif; ?>
                <div>
                    <button class="btn more-info">Recept tonen</button><br>
                    <a href="update_recipe.php?recipe_id=<?php echo $boek['Boek_id']; ?>">
                        <button class="btn update-btn">Edit</button><br>
                    </a>
                    <button class="btn delete-btn" onclick="confirmDelete(<?php echo $boek['Boek_id']; ?>)">Delete</button>
                </div>
            </div>
            <div class="overlay-bg"></div>
        </div>
    <?php } ?>

    <script>
        function confirmDelete(recipeId) {
            var confirmDelete = confirm("Are you sure you want to delete this recipe?");
            if (confirmDelete) {
                window.location.href = "delete_recipe-home.php?recipe_id=" + recipeId;
            }
        }
    </script>

    <!-- ... Your footer code ... -->

</body>
</html>
