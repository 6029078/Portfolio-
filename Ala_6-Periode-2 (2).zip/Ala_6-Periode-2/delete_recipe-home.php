<?php
require_once 'dbconnect.php';

// Check if the recipe_id parameter is set in the URL
if (isset($_GET['recipe_id'])) {
    $recipeId = $_GET['recipe_id'];

    try {
        // Prepare and execute SQL query to delete the recipe with the specified recipe_id
        $deleteSql = "DELETE FROM recepteboeken WHERE Boek_id = ?";
        $deleteStmt = $conn->prepare($deleteSql);
        $deleteStmt->bind_param("i", $recipeId);

        if ($deleteStmt->execute()) {
            // Recipe deleted successfully, you can redirect to another page or display a success message
            header("Location: Home-admin.php");
            exit();
        } else {
            // Display an error message if deletion fails
            echo "Failed to delete recipe.";
        }

        // Close the statement
        $deleteStmt->close();
    } catch (Exception $e) {
        // Display an error message if an exception occurs
        echo "An error occurred: " . $e->getMessage();
    }
}
?>
